# go_vue_blog

# 设置后台端口为4000

# 设置用户前端端口8000

# 更换环境的话，需要更改配置文件confi/app.conf和front_end/config/index.js

