'use strict'
module.exports = {
    NODE_ENV: '"production"',
    //API_DOMAIN: '"http://localhost"', //cxt 生产环境用域名
    API_DOMAIN: '"http://39.100.119.126"',
    API_PORT: '"4000"'
}
